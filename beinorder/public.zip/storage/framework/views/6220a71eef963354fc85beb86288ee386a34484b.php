<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Orders Management</small></h3>
            </div>
        </div>

        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>My Orders </h2>
                        <a data-toggle="tooltip" data-placement="bottom" title="All Restaurants"
                            href="<?php echo e(Route('restaurants.active')); ?>"><i class="fa fa-eye"></i></a></h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card-box table-responsive">
                                    <table id="datatable-responsive"
                                        class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                        width="100%">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th></th>
                                                <th></th>
                                                <th>Order Code</th>
                                                <th>Order Date</th>
                                                <th>Order Status</th>
                                                <th>Restaurant</th>
                                                <th>Branch</th>
                                                <th>Phone Number</th>
                                                <th>Car Color</th>
                                                <th>Car Type</th>
                                                <th>Payment Method</th>
                                                <th>Order Type</th>
                                                <th>Notes</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td></td>
                                                <td><a href="<?php echo e(Route('order_details.index',$order->id)); ?>"><i
                                                            class="fa fa-info-circle"></i></a></td>
                                                <td><?php if($order->orderStatus->status_name=='Active'): ?>
                                                    <a href="<?php echo e(Route('order.checkout',$order->id)); ?>"><i
                                                            class="fa fa-shopping-cart"></i> Check Out</a>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($order->order_code); ?></td>
                                                <td><?php echo e(!empty($order->created_at) ? $order->created_at:''); ?></td>
                                                <td><?php echo e(!empty($order->orderStatus) ? $order->orderStatus->status_name:''); ?>

                                                </td>
                                                <td><?php echo e(!empty($order->restaurant) ? $order->restaurant->rest_name:''); ?>

                                                </td>
                                                <td><?php echo e(!empty($order->branch) ? $order->branch->branch_name:''); ?></td>
                                                <td><?php echo e(!empty($order->phone_number) ? $order->phone_number:''); ?></td>
                                                <td><?php echo e(!empty($order->car_color) ? $order->car_color:''); ?></td>
                                                <td><?php echo e(!empty($order->car_type) ? $order->car_type:''); ?></td>
                                                <td><?php echo e(!empty($order->payment_method) ? $order->payment_method->method_name:''); ?>

                                                </td>
                                                <td><?php echo e(!empty($order->orderType) ? $order->orrderType->type_name:''); ?>

                                                </td>
                                                <td><?php echo e(!empty($order->notes) ? $order->notes:''); ?></td>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beinorder\resources\views/order/index.blade.php ENDPATH**/ ?>