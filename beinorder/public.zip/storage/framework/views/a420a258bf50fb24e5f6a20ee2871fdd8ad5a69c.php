<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><?php echo e($rest->rest_name); ?></h3>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="">
            <?php $__currentLoopData = $prod_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><?php echo e($type->type_name); ?></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>

                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form id="<?php echo e($product->id); ?>" data-parsley-validate class="form-horizontal form-label-left"
                        action="<?php echo e(Route('order_details.store')); ?>" method="GET">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="product_id" id="product_id" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="rest_id" id="rest_id" value="<?php echo e($rest->id); ?>">
                        <?php if($type->type_name==$product->productType->type_name): ?>
                        <div class="x_content">
                            <div class="col-md-7 col-sm-7 ">
                                <div class="product-image">
                                    <img src="<?php echo e(asset('images\products\\').$product->img_path); ?>" />
                                </div>
                            </div>

                            <div class="col-md-5 col-sm-5 " style="border:0px solid #e5e5e5;">

                                <h3 class="prod_title"><?php echo e($product->product_name); ?></h3>

                                <p><?php echo e($product->product_description); ?></p>
                                <br />
                                <div class="">
                                    <div class="product_price">
                                        <h1 class="price"><?php echo e($product->price); ?> <?php echo e($rest->country->currency_symbol); ?>

                                        </h1>
                                    </div>
                                </div>

                                <div class="">
                                    <h2>Size <small>Please select one</small></h2>
                                    <ul class="list-inline prod_size display-layout">
                                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($size->product_id==$product->id): ?>
                                        <input type="radio" class="flat" name="size_id" id="size_id"
                                            value="<?php echo e($size->id); ?>" required />&nbsp;<?php echo e($size->size_name); ?>

                                        ( <?php echo e($size->price); ?> <?php echo e($rest->country->currency_symbol); ?> )
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <br />

                                <div class="">
                                    <h2>Extra <small>Please select one</small></h2>
                                    <ul class="list-inline prod_size display-layout">
                                        <?php $__currentLoopData = $product->extras(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" class="flat" name="extra" id="<?php echo e($extra->id); ?>"
                                            value="<?php echo e($extra->id); ?>" /><?php echo e($extra->extra_name); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <br />

                                <div class="">
                                    <button type="submit" class="btn btn-round btn-success"><i
                                            class="fa fa-shopping-cart"></i> Add to
                                        Cart</button>
                                    
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </form>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="clearfix"></div>
    </div>
    <!-- /page content -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beinorder\resources\views/restaurant/details.blade.php ENDPATH**/ ?>