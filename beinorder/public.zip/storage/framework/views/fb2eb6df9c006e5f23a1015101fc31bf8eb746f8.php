<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Restaurant QR Code</small></h3>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 ">


                <form id="qr-restaurant" data-parsley-validate class="form-horizontal form-label-left" action="#"
                    method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="item form-group">
                     <a download="1"><?php echo $qr; ?></a>
                    </div>
                    <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Save
                        Code</button></div>
                </form>

            </div>

        </div>
    </div>
</div>
<!-- /page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beinorder\resources\views/restaurant/qrcode.blade.php ENDPATH**/ ?>