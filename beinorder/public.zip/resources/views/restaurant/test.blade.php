@extends('layouts.master')

@section('content')
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Restaurant QR Code</small></h3>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                {{-- {{ Session::put('products', substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6)."-".substr(str_shuffle("0123456789"), 0, 4)) }} --}}
{{-- {{ Session::put('products', '#' . str_pad(1, 8, "0", STR_PAD_LEFT)) }} --}}
                {{Session::get('products')}}
                {{ $_SERVER['REMOTE_ADDR'] }}
            </div>

        </div>
    </div>
</div>
<!-- /page content -->
@endsection
