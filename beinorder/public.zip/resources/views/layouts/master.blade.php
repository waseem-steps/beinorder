<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{ config('app.name', 'Beinorder') }}</title>

    <!-- Bootstrap -->
    <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="{{ asset('css/vendors/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="{{ asset('css/vendors/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
    <!-- NProgress -->
    <link href="{{ asset('css/vendors/nprogress/nprogress.css') }}" rel="stylesheet">
    <!-- iCheck -->
    <link href="{{ asset('css/vendors/iCheck/skins/flat/green.css') }}" rel="stylesheet">
    <!-- Dropzone.js -->
    <link href="{{ asset('css/vendors/dropzone/dist/min/dropzone.min.css')}}" rel="stylesheet">
    <!-- Datatables -->
    <link href="{{ asset('css/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css') }}"
        rel="stylesheet">
    <link href="{{ asset('css/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css') }}"
        rel="stylesheet">
    <link href="{{ asset('css/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css') }}" rel="stylesheet">

    <!-- PNotify -->
    <link href="{{ asset('css/vendors/pnotify/dist/pnotify.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/pnotify/dist/pnotify.buttons.css') }}" rel="stylesheet">
    <link href="{{ asset('css/vendors/pnotify/dist/pnotify.nonblock.css') }}" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="{{ asset('css/build/css/custom.min.css') }}" rel="stylesheet">
</head>

<body class="nav-md">
    {{ Session::put('client_ip',$_SERVER['REMOTE_ADDR']) }}
    <div class="container body">
        <div class="main_container">
            <div class="col-md-3 left_col">
                <div class="left_col scroll-view">
                    <div class="navbar nav_title" style="border: 0;">
                        <a href="{{ Route('restaurants.active') }}" class="site_title">
                           {{--  <img src="{{ asset('images/logo.jpeg') }}"> --}}
                        <svg  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <image  height="55px" href="{{ asset('images/logo.svg') }}" />
                        </svg>
                        </a>
                        {{-- <a href="{{ Route('/') }}" class="site_title"><span>Beinorder</span></a> --}}
                    </div>
                    <div class="clearfix"></div>

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                <div class="menu_section">
                    <ul class="nav side-menu">
                        <li><a href="{{Route('restaurants.index')}}"><i class="fa fa-home"></i> Restaurants </a>
                        </li>
                        {{-- <li><a href="{{Route('restaurants.index')}}"><i class="fa fa-users"></i> Users </a>
                        </li>
                        <li><a href="{{Route('restaurants.index')}}"><i class="fa fa-home"></i> Roles </a>
                        </li>
                        <li><a href="{{Route('restaurants.index')}}"><i class="fa fa-lock"></i> Permissions </a>
                        </li> --}}
                        <li><a href="{{Route('plans.index')}}"><i class="fa fa-home"></i> Subscriptions </a>
                        </li>
                        <li><a href="{{Route('countries.index')}}"><i class="fa fa-home"></i> Countries </a>
                        </li>
                        {{-- <li><a href="{{Route('restaurants.index')}}"><i class="fa fa-home"></i> Products </a>
                        </li>--}}
                        {{-- <li><a href="{{Route('restaurants.index')}}"><i class="fa fa-home"></i> Product Categories </a>
                        </li>
                        <li><a href="{{Route('restaurants.index')}}"><i class="fa fa-home"></i> Product Types </a>
                        </li> --}}
                        <li><a href="{{Route('orders.index')}}"><i class="fa fa-home"></i> Orders </a>
                        </li>
                        <li><a href="{{Route('restaurants.index')}}"><i class="fa fa-money"></i> Payments </a>
                        </li>
                        <li><a href="{{Route('plans.index')}}"><i class="fa fa-home"></i> Price Plans </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- /sidebar menu -->
        </div>
    </div>

    <!-- top navigation -->
    <div class="top_nav">
        <div class="nav_menu">
            <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars" style="color:#212529"></i></a>
            </div>
            <nav class="nav navbar-nav">
                <ul class=" navbar-right">
                    <li class="nav-item dropdown open" style="padding-left: 15px;">
                        {{-- <a href="#" class="user-profile dropdown-toggle" aria-haspopup="true"
                            id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                            ع
                        </a> --}}
                        <h2>ع</h2>
                        {{-- <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="javascript:;"> Profile</a>
                            <a class="dropdown-item" href="javascript:;">
                                <span class="badge bg-red pull-right">50%</span>
                                <span>Settings</span>
                            </a>
                            <a class="dropdown-item" href="javascript:;">Help</a>
                            <a class="dropdown-item" href="login.html"><i class="fa fa-sign-out pull-right"></i>
                                Log Out</a>
                        </div> --}}
                    </li>

                    {{-- <li role="presentation" class="nav-item dropdown open">
                        <a href="javascript:;" class="dropdown-toggle info-number" id="navbarDropdown1"
                            data-toggle="dropdown" aria-expanded="false">
                            <i class="fa fa-envelope-o"></i>
                            <span class="badge bg-green">6</span>
                        </a>
                        <ul class="dropdown-menu list-unstyled msg_list" role="menu" aria-labelledby="navbarDropdown1">
                            <li class="nav-item">
                                <a class="dropdown-item">
                                    <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                    <span>
                                        <span>John Smith</span>
                                        <span class="time">3 mins ago</span>
                                    </span>
                                    <span class="message">
                                        Film festivals used to be do-or-die moments for movie makers. They were
                                        where...
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </li> --}}
                </ul>
            </nav>
        </div>
    </div>
    <!-- /top navigation -->

    <!-- page content -->
    @yield('content')
    <!-- /page content -->

    <!-- footer content -->
    <footer>
        <div class="pull-right">
            Powered by <a href="http://www.shahin-eng.com/">SEF</a>
        </div>
        <div class="clearfix"></div>
    </footer>
    <!-- /footer content -->
    </div>
    </div>

    <!-- jQuery -->
    <script src="{{ asset('js/vendors/jquery/dist/jquery.min.js') }}"></script>
    <!-- Bootstrap -->
    <script src="{{ asset('js/vendors/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
    <!-- FastClick -->
    <script src="{{ asset('js/vendors/fastclick/lib/fastclick.js') }}"></script>
    <!-- NProgress -->
    <script src="{{ asset('js/vendors/nprogress/nprogress.js') }}"></script>
    <!-- Dropzone.js -->
    <script src="{{ asset('js/vendors/dropzone/dist/min/dropzone.min.js') }}"></script>
    <!-- iCheck -->
    <script src="{{ asset('js/vendors/iCheck/icheck.min.js') }}"></script>

    <!-- Datatables -->
    <script src="{{ asset('js/vendors/datatables.net/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-buttons/js/dataTables.buttons.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-buttons/js/buttons.flash.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-buttons/js/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-buttons/js/buttons.print.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-responsive/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js') }}"></script>
    <script src="{{ asset('js/vendors/datatables.net-scroller/js/dataTables.scroller.min.js') }}"></script>
    <script src="{{ asset('js/vendors/jszip/dist/jszip.min.js') }}"></script>
    <script src="{{ asset('js/vendors/pdfmake/build/pdfmake.min.js') }}"></script>
    <script src="{{ asset('js/vendors/pdfmake/build/vfs_fonts.js') }}"></script>
<!-- Dropzone.js -->
    <script src="../vendors/dropzone/dist/min/dropzone.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="{{ asset('js/build/js/custom.min.js') }}"></script>
</body>

</html>
