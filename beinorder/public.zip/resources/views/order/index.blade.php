@extends('layouts.master')

@section('content')
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Orders Management</small></h3>
            </div>
        </div>

        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>My Orders </h2>
                        <a data-toggle="tooltip" data-placement="bottom" title="All Restaurants"
                            href="{{ Route('restaurants.active') }}"><i class="fa fa-eye"></i></a></h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card-box table-responsive">
                                    <table id="datatable-responsive"
                                        class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                        width="100%">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th></th>
                                                <th></th>
                                                <th>Order Code</th>
                                                <th>Order Date</th>
                                                <th>Order Status</th>
                                                <th>Restaurant</th>
                                                <th>Branch</th>
                                                <th>Phone Number</th>
                                                <th>Car Color</th>
                                                <th>Car Type</th>
                                                <th>Payment Method</th>
                                                <th>Order Type</th>
                                                <th>Notes</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($orders as $order)
                                            <tr>
                                                <td></td>
                                                <td><a href="{{Route('order_details.index',$order->id)  }}"><i
                                                            class="fa fa-info-circle"></i></a></td>
                                                <td>@if($order->orderStatus->status_name=='Active')
                                                    <a href="{{Route('order.checkout',$order->id)  }}"><i
                                                            class="fa fa-shopping-cart"></i> Check Out</a>
                                                    @endif
                                                </td>
                                                <td>{{ $order->order_code }}</td>
                                                <td>{{ !empty($order->created_at) ? $order->created_at:'' }}</td>
                                                <td>{{ !empty($order->orderStatus) ? $order->orderStatus->status_name:'' }}
                                                </td>
                                                <td>{{ !empty($order->restaurant) ? $order->restaurant->rest_name:'' }}
                                                </td>
                                                <td>{{ !empty($order->branch) ? $order->branch->branch_name:'' }}</td>
                                                <td>{{ !empty($order->phone_number) ? $order->phone_number:'' }}</td>
                                                <td>{{ !empty($order->car_color) ? $order->car_color:'' }}</td>
                                                <td>{{ !empty($order->car_type) ? $order->car_type:'' }}</td>
                                                <td>{{ !empty($order->payment_method) ? $order->payment_method->method_name:'' }}
                                                </td>
                                                <td>{{ !empty($order->orderType) ? $order->orrderType->type_name:'' }}
                                                </td>
                                                <td>{{ !empty($order->notes) ? $order->notes:'' }}</td>

                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->
@endsection
