@extends('layouts.master')

@section('content')
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Pricing Tables</h3>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12  ">
                <div class="x_panel" style="height:600px;">
                    <div class="x_content">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- price element -->
                                @foreach($plans as $plan)
                                    <div class="col-md-3 col-sm-6  ">
                                        <div class="pricing">
                                            <div class="title">
                                                <h2>{{ $plan->plan_name }}</h2>
                                                <h1>{{ $plan->price }} {{ $plan->country->country_currency}}</h1>
                                                <span>
                                                    @if($plan->period==7)
                                                        Weekly
                                                        @elseif($plan->period==30)
                                                        Monthly
                                                        @elseif($plan->period==120)
                                                        Quarterly
                                                        @elseif($plan->period==180)
                                                        Half-Year
                                                        @elseif($plan->period==365)
                                                        Yearly
                                                        @else
                                                        {{  $plan->period}} days
                                                        @endif
                                                </span>
                                            </div>
                                            <div class="x_content">
                                                <div class="">
                                                    <div class="pricing_features">
                                                        <ul class="list-unstyled text-left">
                                                            <li>Total Brancehs: {{ $plan->branch_count }}</li>
                                                            <li>Period: {{ $plan->period }} day(s)</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="pricing_footer">
                                                    <a href="javascript:void(0);" class="btn btn-success btn-block" role="button">Subscribe<span>
                                                            now!</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                                <!-- price element -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->
@endsection