@extends('layouts.master')

@section('content')
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Orders Management</small></h3>
            </div>
        </div>

        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>My Order Details </h2>
                        <a data-toggle="tooltip" data-placement="bottom" title="All Restaurants"
                            href="{{ Route('restaurants.active') }}"><i class="fa fa-eye"></i></a></h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card-box table-responsive">
                                    <table id="datatable-responsive"
                                        class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                        width="100%">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th></th>
                                                <th>Order Code</th>
                                                <th>Order Detail Date</th>
                                                <th>Restaurant</th>
                                                <th>Branch</th>
                                                <th>Product</th>
                                                <th>Size</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Amount</th>
                                                <th>Notes</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($order_details as $order_detail)
                                            <tr>
                                                <td></td>
                                                <td>
                                                    @if($order_detail->order->orderStatus->status_name=='Active')
                                                    <a href="{{ Route('order_details.delete',$order_detail->id) }}"><i class="fa fa-remove"></i></a>
                                                    @endif
                                                </td>
                                                <td>{{ $order_detail->order->order_code }}</td>
                                                <td>{{ !empty($order_detail->created_at) ? $order_detail->created_at:'' }}
                                                </td>
                                                <td>{{ !empty($order_detail->order->restaurant) ? $order_detail->order->restaurant->rest_name:'' }}
                                                </td>
                                                <td>{{ !empty($order_detail->order->branch) ? $order_detail->order->branch->branch_name:'' }}
                                                </td>
                                                <td>{{ !empty($order_detail->product->product_name) ? $order_detail->product->product_name:'' }}
                                                </td>
                                                <td>{{ !empty($order_detail->productSize->size_name) ? $order_detail->productSize->size_name:'' }}
                                                </td>
                                                <td>{{ !empty($order_detail->productSize->price) ? $order_detail->productSize->price:'' }}
                                                </td>
                                                <td>{{ $order_detail->quantity }}</td>
                                                <td>{{ $order_detail->quantity * !empty($order_detail->productSize->price) ? $order_detail->productSize->price:2 }}
                                                </td>
                                                <td>{{ !empty($order_detail->notes) ? $order_detail->notes:'' }}</td>

                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->
@endsection
