<?php

use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/countries', 'CountryController@index')->name('countries.index');
Route::post('/country/store', 'CountryController@store')->name('country.store');
Route::get('/country/delete/{id}', 'CountryController@delete')->name('country.delete');

Route::get('/branches/{id}','BranchController@index')->name('branches.index');
Route::POST('/branch/add', 'BranchController@store')->name('branch.store');
Route::get('/branch/delete/{id}', 'BranchController@delete')->name('branch.delete');
Route::get('/branch/edit/{id}', 'BranchController@edit')->name('branch.edit');
Route::post('/branch/update/{id}', 'BranchController@update')->name('branch.update');
Route::get('/branch/lock/{id}', 'BranchController@lock')->name('branch.lock');
Route::get('/branch/unlock/{id}', 'BranchController@unlock')->name('branch.unlock');

Route::get('/products/{id}', 'ProductController@index')->name('products.index');
Route::post('/product/store', 'ProductController@store')->name('product.store');
Route::get('/product/delete/{id}', 'ProductController@delete')->name('product.delete');
Route::get('/product/edit/{id}', 'ProductController@edit')->name('product.edit');
Route::post('/product/update/{id}', 'ProductController@update')->name('product.update');

Route::get('/productsizes/{id}', 'ProductSizeController@index')->name('product_sizes.index');
Route::post('/productsize/store', 'ProductSizeController@store')->name('product_size.store');
Route::get('/productsize/delete/{id}', 'ProductSizeController@delete')->name('product_size.delete');
Route::get('/productsize/edit/{id}', 'ProductSizeController@edit')->name('product_size.edit');
Route::post('/productsize/update/{id}', 'ProductSizeController@update')->name('product_size.update');

Route::get('/restaurants', 'RestaurantController@index')->name('restaurants.index');
Route::post('/restaurant/store', 'RestaurantController@store')->name('restaurant.store');
Route::get('/restaurant/delete/{id}', 'RestaurantController@delete')->name('restaurant.delete');
Route::get('/restaurant/edit/{id}', 'RestaurantController@edit')->name('restaurant.edit');
Route::post('/restaurant/update/{id}', 'RestaurantController@update')->name('restaurant.update');
Route::get('/restaurant/lock/{id}','RestaurantController@lock')->name('restaurant.lock');
Route::get('/restaurant/unlock/{id}', 'RestaurantController@unlock')->name('restaurant.unlock');
Route::get('/restaurant/details/{id}', 'RestaurantController@details')->name('restaurant.details');
Route::get('/restaurant/qrcode/{id}', 'RestaurantController@generateQrExternal')->name('restaurant.qrcode');
Route::get('/restaurants/all','RestaurantController@getActive')->name('restaurants.active');

Route::get('/plans','PricePlanController@index')->name('plans.index');

//Route::get('/payment/pay','PaymentController@pay');

Route::get('/orderdetails/{id}','OrderDetailController@index')->name('order_details.index');
Route::get('/orderdetails/delete/{id}', 'OrderDetailController@delete')->name('order_details.delete');
Route::get('/addOrder', 'OrderDetailController@store')->name('order_details.store');
Route::get('/createOrder', 'OrderDetailController@create')->name('order_details.create');
Route::post('/newOrder', 'OrderDetailController@new_order')->name('order_details.new_order');

Route::get('/orders', 'OrderController@index')->name('orders.index');
Route::get('/order/checkout/{id}', 'OrderController@checkout')->name('order.checkout');

Route::get('/test',function(){
    return view ('restaurant.test');
});


